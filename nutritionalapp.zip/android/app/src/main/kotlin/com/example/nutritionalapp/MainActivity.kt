package com.example.nutritionalapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
